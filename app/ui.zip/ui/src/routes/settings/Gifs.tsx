export function Gifs() {
    return <div className="slds-text-heading_medium">GIFs</div>;
}
