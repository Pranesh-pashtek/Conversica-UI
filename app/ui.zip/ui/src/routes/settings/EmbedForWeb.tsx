export function EmbedForWeb() {
    return <div className="slds-text-heading_medium">Embed for web</div>;
}
