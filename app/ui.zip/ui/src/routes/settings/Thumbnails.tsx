export function Thumbnails() {
    return <div className="slds-text-heading_medium">Thumbnails</div>;
}
